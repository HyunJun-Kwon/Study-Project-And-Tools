window.onload = function () {


  var diseaseName = document.querySelector('#diseaseName');
  var diseaseNameOption = diseaseName.options[diseaseName.selectedIndex].innerText;

  var subject = document.querySelector('#subject');
  var subjectOption = subject.options[subject.selectedIndex].innerText;

  subject.onchange = function () {
    if (subjectOption === '진료 과목') {
      diseaseNameOption.options.length = 0;
      diseaseNameOption.innerText = '상병'
    }
  }

  var chartData = [
    [
      {
        label: '총 환자수',
        data: [150, 157, 160, 154, 170, 180],
        borderWidth: 3,
        borderColor: 'black',
        backgroundColor: 'black',
        // tension: 0.4,
      },
      {
        label: '20세 미만',
        data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
        backgroundColor: ['red'],
        borderWidth: 1,
        borderColor: 'red',
        // tension: 0.4,
      },
      {
        label: '20-29세',
        data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
        backgroundColor: ['blue'],
        borderWidth: 1,
        borderColor: 'blue',
        // tension: 0.4,
      },
      {
        label: '30-39세',
        data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
        backgroundColor: ['green'],
        borderWidth: 1,
        borderColor: 'green',
        // tension: 0.4,
      },
      {
        label: '40-49세',
        data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
        backgroundColor: ['purple'],
        borderWidth: 1,
        borderColor: 'purple',
        // tension: 0.4,
      },
      {
        label: '50-59세',
        data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
        backgroundColor: ['orange'],
        borderWidth: 1,
        borderColor: 'orange',
        // tension: 0.4,
      },
      {
        label: '60-69세',
        data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
        backgroundColor: ['brown'],
        borderWidth: 1,
        borderColor: 'brown',
        // tension: 0.4,
      },
      {
        label: '70세 이상',
        data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
        backgroundColor: ['cadetblue'],
        borderWidth: 1,
        borderColor: 'cadetblue',
        // tension: 0.4,
      }
    ],
    [
      {
        label: '총 환자수',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        borderWidth: 3,
        borderColor: 'black',
        backgroundColor: 'black',
        // tension: 0.4,
      },
      {
        label: '20세 미만',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)], backgroundColor: ['red'],
        borderWidth: 1,
        borderColor: 'red',
        // tension: 0.4,
      },
      {
        label: '20-29세',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)], backgroundColor: ['blue'],
        borderWidth: 1,
        borderColor: 'blue',
        // tension: 0.4,
      },
      {
        label: '30-39세',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['green'],
        borderWidth: 1,
        borderColor: 'green',
        // tension: 0.4,
      },
      {
        label: '40-49세',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['purple'],
        borderWidth: 1,
        borderColor: 'purple',
        // tension: 0.4,
      },
      {
        label: '50-59세',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['orange'],
        borderWidth: 1,
        borderColor: 'orange',
        // tension: 0.4,
      },
      {
        label: '60-69세',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['brown'],
        borderWidth: 1,
        borderColor: 'brown',
        // tension: 0.4,
      },
      {
        label: '70세 이상',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['cadetblue'],
        borderWidth: 1,
        borderColor: 'cadetblue',
        // tension: 0.4,
      }
    ]
  ]
  var subjectArea = document.getElementById('patientChart').getContext('2d');
  var subjectChart = new Chart(subjectArea, {
    type: 'line',
    data: {
      labels: ['2017', '2018', '2019', '2020', '2021', '2022'],
      datasets: [
        {
          label: '총 환자수',
          data: [150, 157, 160, 154, 170, 180],
          borderWidth: 3,
          borderColor: 'black',
          backgroundColor: 'black',
          // tension: 0.4,
        },
      ]
    },
    options: {
      reponsive: true,
      maintainAspectRatio: false,
      scales: {

        y: {
          grid: {
            display: true,
            color: 'rgba(0, 0, 0, 0.3)',
          },
          beginAtZero: true,
          min: 0,
          max: 200,
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:만명)' + value;
              } else {
                return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
              }
            },
          },
        },
      },
      plugins: {
        title: {
          display: true,
          text: diseaseNameOption,
          font: {
            size: 30,
          }
        },
        legend: {
          display: false,
          labels: {
            usePointStyle: true
          },
          onClick: (e, legendItem) => {
            const index = legendItem.datasetIndex;
            const meta = subjectChart.getDatasetMeta(index);
            meta.hidden = meta.hidden === null ? !subjectChart.data.datasets[index].hidden : null;
            subjectChart.update();
          }
        },
      },
    }
  });

  var saleArea = document.getElementById('saleChart').getContext('2d');
  var saleChart = new Chart(saleArea, {
    type: 'line',
    data: {
      labels: ['2017', '2018', '2019', '2020', '2021', '2022'],
      datasets: [
        {
          label: '총 환자수',
          data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)], backgroundColor: ['red'],
          borderWidth: 3,
          borderColor: 'black',
          backgroundColor: 'black',
          // tension: 0.4,
        },
      ]
    },
    options: {
      reponsive: true,
      maintainAspectRatio: false,
      scales: {

        y: {
          grid: {
            display: true,
            color: 'rgba(0, 0, 0, 0.3)',
          },
          beginAtZero: true,
          min: 0,
          max: 16000,
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:1억)' + value;
              } else {
                return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
              }
            },
          },
        },
      },
      plugins: {
        title: {
          display: true,
          text: "충치",
          font: {
            size: 30,
          }
        },
        legend: {
          display: false,
          labels: {
            usePointStyle: true
          },
          onClick: (e, legendItem) => {
            const index = legendItem.datasetIndex;
            const meta = saleChart.getDatasetMeta(index);
            meta.hidden = meta.hidden === null ? !saleChart.data.datasets[index].hidden : null;
            saleChartChart.update();
          }
        },
      },
    }
  });

  var checkBoxes = document.querySelectorAll('.checkBoxes input')
  // console.log(checkBoxes);

  for (var i = 0; i < checkBoxes.length; i++) {
    checkBoxes[i].onclick = function (event) {
      var result = '';
      if (event.target.checked) {
        result = parseInt(event.target.value);
        console.log(result);
        subjectChart.data.datasets.push(chartData[0][result]);
        saleChart.data.datasets.push(chartData[1][result]);
        subjectChart.update();
        saleChart.update();
      } else {
        result = parseInt(event.target.value);
        for (var j = 0; j < saleChart.data.datasets.length; j++) {
          if (saleChart.data.datasets[j].label === chartData[0][result].label) {
            saleChart.data.datasets.splice(j, 1);
            subjectChart.data.datasets.splice(j, 1)
            break;
          }
        }
        subjectChart.update();
        saleChart.update();
      }
    }
  }

  diseaseName.onchange = function () {
    var diseaseNames = diseaseName.options[diseaseName.selectedIndex].innerText;
    var title = diseaseNames;
    saleChart.options.plugins.title.text = title;
    subjectChart.options.plugins.title.text = title;


    for (var i = 0; i < saleChart.data.datasets.length; i++) {
      var newData = [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000),
      Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)];
      saleChart.data.datasets[i].data = newData;
    }
    saleChart.update();
    subjectChart.update();
  }



}


