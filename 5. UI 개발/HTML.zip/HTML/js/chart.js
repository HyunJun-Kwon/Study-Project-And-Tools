window.onload = function () {
  var region =localStorage.getItem("region");
  var income =localStorage.getItem("income");
  var rent =localStorage.getItem("rent")
  console.log(region+''+income+''+rent)
  var chartArea = document.getElementById('myChart1').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'bar',
    data: {
      labels: ['서울', region],
      datasets: [{
        label: '유동인구',
        data: [Math.floor(Math.random()*100), Math.floor(Math.random()*100)],
        backgroundColor: ['red','blue'],
        // borderColor: 'none',
        borderWidth: 1
      }]
    },
    options: {
      plugins: {
        legend: {
          display: false
        }
      },
      responsive: false,
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 100
        }
      }
    },
  });

  var chartArea = document.getElementById('myChart2').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'bar',
    data: {
      labels: ['서울', region],
      datasets: [{
        label: '의원 개수',
        data: [Math.floor(Math.random()*100), Math.floor(Math.random()*100)],
        backgroundColor: ['red','blue'],
        
        borderWidth: 1
      }]
    },
    options: {
      plugins: {
        legend: {
          display: false
        }
      },
      responsive: false,
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 100
        }
      }
    },
  });


  var chartArea = document.getElementById('myChart3').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'bar',
    data: {
      labels: ['서울', region],
      datasets: [{
        label: '소득 수준',
        data: [Math.floor(Math.random()*100), income],
        backgroundColor: ['red','blue'],
        
        borderWidth: 1
      }]
    },
    options: {
      plugins: {
        legend: {
          display: false
        }
      },
      responsive: false,
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 100
        }
      }
    },
  });

  var chartArea = document.getElementById('myChart4').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'bar',
    data: {
      labels: ['서울', region],
      datasets: [{
        label: '임대료',
        data: [Math.floor(Math.random()*100), rent],
        backgroundColor: ['red','blue'],
        
        borderWidth: 1
      }]
    },
    options: {
      plugins: {
        legend: {
          display: false
        }
      },
      responsive: false,
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 100
        }

      }
    },
  });
  
    var patient = document.querySelector("#patientPredict");
    var sales = document.querySelector("#salesPredict");
    patient.textContent = '예상 환자수는'+123+'명 입니다.'
    sales.textContent = '예상 월 매출은 '+123123123+'원 입니다.'
  

    
}