window.onload = function () {
  var region = localStorage.getItem("region");
  var income = localStorage.getItem("income");
  var rent = localStorage.getItem("rent")
  var count = localStorage.getItem("count")
  console.log(region + '' + income + '' + rent + '' + count)

  var chartArea = document.getElementById('myChart1').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'bar',
    data: {
      labels: ['서울', region],
      datasets: [{
        // label: '인구',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['rgba(255,0,0,0.5)', 'rgba(36, 189, 255, 0.66)'],
        // borderColor: 'none',
        borderWidth: 1
      }]
    },
    options: {
      reponsive : true,
      maintainAspectRatio : false,
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 16000,
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:1만)' + value;
              } else {
                return value;
              }
            },
            font: {
              size: 20,
            }
          },
        },
      },
      plugins: {
        title: {
          display: true,
          text: '인구',
          font: {
            size: 30,
          }
        },
        legend: {
          display: false

        }
      },
      // responsive: false,
      // scales: {
      //   x:{
      //     ticks:{
      //       font:{
      //         size:30
      //       }
      //     }
      //   },

      // }
    }
  });

  var chartArea = document.getElementById('myChart2').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'bar',
    data: {
      labels: ['서울', region],
      datasets: [{
        label: '유동 인구',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['rgba(255,0,0,0.5)', 'rgba(36, 189, 255, 0.66)'],

        borderWidth: 1
      }]
    },
    options: {
      reponsive : true,
      maintainAspectRatio : false,
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 16000,
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:1만)' + value;
              } else {
                return value;
              }
            },
          },
        },
      },
      plugins: {
        title: {
          display: true,
          text: '유동 인구',
          font: {
            size: 30,
          }
        },
        legend: {
          display: false
        }
      },
    },
  });


  var chartArea = document.getElementById('myChart3').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'bar',
    data: {
      labels: ['서울', region],
      datasets: [{
        label: '소득 수준',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['rgba(255,0,0,0.5)', 'rgba(36, 189, 255, 0.66)'],

        borderWidth: 1
      }]
    },
    options: {
      reponsive : true,
      maintainAspectRatio : false,
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 16000,
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:1만)' + value;
              } else {
                return value;
              }
            },
          },
        },
      },
      plugins: {
        title: {
          display: true,
          text: '소득 수준',
          font: {
            size: 30,
          }
        },
        legend: {
          display: false
        }
      },
    },
  });

  var chartArea = document.getElementById('myChart4').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'bar',
    data: {
      labels: ['서울', region],
      datasets: [{
        label: '의원 개수',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['rgba(255,0,0,0.5)', 'rgba(36, 189, 255, 0.66)'],

        borderWidth: 1
      }]
    },
    options: {
      reponsive : true,
      maintainAspectRatio : false,
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 16000,
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:1만)' + value;
              } else {
                return value;
              }
            },
          },
        },
      },
      plugins: {
        title: {
          display: true,
          text: '의원 개수',
          font: {
            size: 30,
          }
        },
        legend: {
          display: false
        }
      },
    },
  });

  var chartArea = document.getElementById('myChart5').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'bar',
    data: {
      labels: ['서울', region],
      datasets: [{
        label: '임대료',
        data: [Math.floor(Math.random() * 10000) / 5, Math.floor(Math.random() * 10000) / 5],
        backgroundColor: ['rgba(255,0,0,0.5)', 'rgba(36, 189, 255, 0.66)'],

        borderWidth: 1
      }]
    },
    options: {
      reponsive : true,
      maintainAspectRatio : false,
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 16000,
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:1만)' + value;
              } else {
                return value;
              }
            },
          },
        },
      },
      plugins: {
        title: {
          display: true,
          text: '임대료',
          font: {
            size: 30,
          }
        },
        legend: {
          display: false
        }
      },
    },
  });

  var chartMenu1 = document.querySelector("#myChart1");
  var chartMenu2 = document.querySelector("#myChart2");
  var chartMenu3 = document.querySelector("#myChart3");
  var chartMenu4 = document.querySelector("#myChart4");
  var chartMenu5 = document.querySelector("#myChart5");
  var chartPopulation = document.querySelector('.chartPopulation');
  chartPopulation.onclick = function () {

    chartMenu1.style.opacity = 1;
    chartMenu2.style.opacity = 0;
    chartMenu3.style.opacity = 0;
    chartMenu4.style.opacity = 0;
    chartMenu5.style.opacity = 0;
  }
  var chartFloating = document.querySelector('.chartFloating');
  chartFloating.onclick = function () {
    chartMenu1.style.opacity = 0;
    chartMenu2.style.opacity = 1;
    chartMenu3.style.opacity = 0;
    chartMenu4.style.opacity = 0;
    chartMenu5.style.opacity = 0;
  }
  var chartIncome = document.querySelector('.chartIncome');
  chartIncome.onclick = function () {
    chartMenu1.style.opacity = 0;
    chartMenu2.style.opacity = 0;
    chartMenu3.style.opacity = 1;
    chartMenu4.style.opacity = 0;
    chartMenu5.style.opacity = 0;
  }
  var chartCount = document.querySelector('.chartCount');
  chartCount.onclick = function () {
    chartMenu1.style.opacity = 0;
    chartMenu2.style.opacity = 0;
    chartMenu3.style.opacity = 0;
    chartMenu4.style.opacity = 1;
    chartMenu5.style.opacity = 0;
  }

  var chartRent = document.querySelector('.chartRent');
  chartRent.onclick = function () {
    chartMenu1.style.opacity = 0;
    chartMenu2.style.opacity = 0;
    chartMenu3.style.opacity = 0;
    chartMenu4.style.opacity = 0;
    chartMenu5.style.opacity = 1;
  }

  var patient = document.querySelector("#patientPredict");
  var sales = document.querySelector("#salesPredict");
  patient.textContent = '예상 환자수는' + Math.round(Math.random() * 1000) + '명 입니다.'
  sales.textContent = '예상 월 매출은 ' + Math.round(Math.random() * 10000000).toLocaleString('ko-KR') + '원 입니다.'

  window.addEventListener('resize', function () {
    // 현재 윈도우의 폭을 가져오기
    var windowWidth = window.innerWidth;
    console.log(windowWidth)
    // 작은 화면 크기 체크 (예: 600px 이하로 간주)
    if (windowWidth <= 576) {
      // 작은 화면 크기일 때 처리할 함수 호출
      handleSmallScreen();
    }
    if (windowWidth > 576) {
      handleMediumScreen();
    }
    if (windowWidth < 870 && windowWidth > 576) {
      chartMenuSize();
    }
    // 다른 크기 범위에 대한 추가적인 체크와 처리를 할 수 있습니다.
  });
}
function handleSmallScreen() {

  document.getElementById("chartMenuBox").style.display = "block";
  var chartMenu10 = document.querySelector("#chartMenu");
  chartMenu10.style.marginTop = 0;
}
function handleMediumScreen() {
  document.getElementById("chartMenuBox").style.display = 'flex';
  var chartMenu10 = document.querySelector("#chartMenu");
  chartMenu10.style.marginTop = '10%';
}
function chartMenuSize() {
  var chartBox = document.querySelector("#chartBox");
  chartBox.style.height = '50vh';
}




