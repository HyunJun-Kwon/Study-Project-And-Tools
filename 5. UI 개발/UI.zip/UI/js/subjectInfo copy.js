window.onload = function () {
  var code = document.querySelector('#code');
  var codeOption = code.options[code.selectedIndex].innerText;
  
  var subject = document.querySelector('#subject');
  var subjectOption = subject.options[subject.selectedIndex].innerText;
  
  subject.onchange = function () {
    var subjectOption = subject.options[subject.selectedIndex].innerText;
    console.log(subjectOption)
    if (subjectOption === '진료 과목') {
      
      var option = document.createElement('option')
      option.innerText = '상병'
      code.appendChild(option)
    }
  }


  var chartDatasets = [
    {
      label: '총인구',
      data: [153, 158, 169, 166, 176, 183],
      backgroundColor: 'rgba(36, 189, 255, 0.66)',
      // borderColor: 'none',
      borderWidth: 5,
      borderColor: 'rgba(36, 189, 255, 0.66)'      
    },
    {
      label: '20세 미만',
      data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
      backgroundColor: 'red',
      borderWidth: 1,
      borderColor: 'red'
    },
    {
      label: '20대',
      data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
      backgroundColor: 'blue',
      borderWidth: 1,
      borderColor: 'blue'
    },
    {
      label: '30대',
      data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
      backgroundColor: 'green',
      borderWidth: 1,
      borderColor: 'green'
    },
    {
      label: '40대',
      data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
      backgroundColor: ['purple'],
      borderWidth: 1,
      borderColor: 'purple'
    },
    {
      label: '50대',
      data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
      backgroundColor: 'orange',
      borderWidth: 1,
      borderColor: 'orange'
    },
    {
      label: '60대',
      data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
      backgroundColor: 'brown',
      borderWidth: 1,
      borderColor: 'brown'
    },
    {
      label: '70대 이상',
      data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
      backgroundColor: 'skyblue',
      borderWidth: 1,
      borderColor: 'skyblue',
    }]


  console.log(chartDatasets[1])
  var chartArea = document.getElementById('subjectChart').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'line',
    data: {
      labels: ['2017년', '2018년', '2019년', '2020년', '2021년', '2022년'],
      datasets: [
        {
          label: '총인구',
          data: [153, 158, 169, 166, 176, 183],
          backgroundColor: 'black',
          // borderColor: 'none',
          borderWidth: 5,
          borderColor: 'black'        
              
        },
        {
          label: '20세 미만',
          data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
          backgroundColor: 'red',
          borderWidth: 1,
          borderColor: 'red',
          hidden: true
        },
        {
          label: '20대',
          data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
          backgroundColor: 'blue',
          borderWidth: 1,
          borderColor: 'blue',
          hidden: true
        },
        {
          label: '30대',
          data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
          backgroundColor: 'green',
          borderWidth: 1,
          borderColor: 'green',
          hidden: true
        },
        {
          label: '40대',
          data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
          backgroundColor: ['purple'],
          borderWidth: 1,
          borderColor: 'purple',
          hidden: true
        },
        {
          label: '50대',
          data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
          backgroundColor: 'orange',
          borderWidth: 1,
          borderColor: 'orange',
          hidden: true
        },
        {
          label: '60대',
          data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
          backgroundColor: 'brown',
          borderWidth: 1,
          borderColor: 'brown',
          hidden: true
        },
        {
          label: '70대 이상',
          data: [Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100), Math.floor(Math.random() * 100)],
          backgroundColor: 'cadetblue',
          borderWidth: 1,
          borderColor: 'cadetblue',
          hidden: true
        }    
      
    ]
    },
    options: {
      elements: {
        point: {
          pointBorderWidth: 3
        }
      },
      reponsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          // beginAtZero: true,
          min: 0,
          max: 200,
          stepSize: 10,
          position: 'left',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:만명)' + value;
              } else {
                return value;
              }
            },
            font: {
              size: 20,
            }
          },
        },
      },
      plugins: {
        tooltip: true,
        title: {
          display: true,
          text: codeOption,
          font: {
            size: 30,
          }
        },
        legend: {
          display: false

        }
      },
    }
  });
  
  var checkBoxes = document.querySelectorAll('.checkBoxes input') 

  for (var i = 0; i < checkBoxes.length; i++) {   
    
    checkBoxes[i].onclick = function (event) {
      var result = '';
      if (event.target.checked) {
        result = parseInt(event.target.value);        
        myChart.show(result)        
      } else {
        result = parseInt(event.target.value);
        myChart.hide(result);        
      }
    }
  }

  code.onchange = function () {

    codeOption = code.options[code.selectedIndex].innerText;
    
    myChart.options.plugins.title.text = codeOption;
    console.log(myChart.options.plugins.title.text);
    myChart.data.datasets[0].data = [Math.floor(Math.random()*100+100),Math.floor(Math.random()*100+100),Math.floor(Math.random()*100+100),Math.floor(Math.random()*100+100),Math.floor(Math.random()*100+100),Math.floor(Math.random()*100+100)]
    for(var i=1; i<myChart.data.datasets.length; i++){
      var newData = [Math.floor(Math.random()*100), Math.floor(Math.random()*100), Math.floor(Math.random()*100), Math.floor(Math.random()*100), Math.floor(Math.random()*100), Math.floor(Math.random()*100)]
      myChart.data.datasets[i].data = newData;
    }
    
    myChart.update();
  }


}
function addData(chart, label, data) {
  chart.data.labels.push(label);
  chart.data.datasets.forEach((dataset) => {
    dataset.data.push(data);
  });
  chart.update();
}
function removeData(chart) {
  chart.data.labels.pop();
  chart.data.datasets.forEach((dataset) => {
    dataset.data.pop();
  });
  chart.update();
}




