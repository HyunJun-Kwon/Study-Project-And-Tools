window.onload = function () {
  var region = localStorage.getItem("region");
  var income = localStorage.getItem("income");
  var rent = localStorage.getItem("rent")
  var count = localStorage.getItem("count")
  console.log(region + '' + income + '' + rent + '' + count)

  var category = document.querySelector('#category');
  categoryOpiton = category.options[category.selectedIndex].innerText;


  var chartArea = document.getElementById('regionInfoChart').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'line',
    data: {
      labels: ['2017', '2018', '2019', '2020', '2021', '2022'],
      datasets: [
        {
          label: '총 환자수',
          data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)], backgroundColor: ['red'],
          borderWidth: 3,
          borderColor: 'black',
          backgroundColor: 'black',
          // tension: 0.4,
        },
      ]
    },
    options: {
      reponsive: true,
      maintainAspectRatio: false,
      scales: {

        y: {
          grid: {
            display: true,
            color: 'rgba(0, 0, 0, 0.3)',
          },
          beginAtZero: true,
          min: 0,
          max: 16000,
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:1억)' + value;
              } else {
                return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
              }
            },
          },
        },
      },
      plugins: {
        title: {
          display: true,
          text: "충치",
          font: {
            size: 30,
          }
        },
        legend: {
          display: false,
          labels: {
            usePointStyle: true
          },
          onClick: (e, legendItem) => {
            const index = legendItem.datasetIndex;
            const meta = myChart.getDatasetMeta(index);
            meta.hidden = meta.hidden === null ? !myChart.data.datasets[index].hidden : null;
            myChart.update();
          }
        },
      },
    }
  });


}
