window.onload = function () {


  var diseaseName = document.querySelector('#diseaseName');
  var diseaseNameOption = diseaseName.options[diseaseName.selectedIndex].innerText;

  var subject = document.querySelector('#subject');
  var subjectOption = subject.options[subject.selectedIndex].innerText;

  subject.onchange = function () {
    if (subjectOption === '진료 과목') {
      diseaseNameOption.options.length = 0;
      diseaseNameOption.innerText = '상병'
    }
  }

  var chartDatasets = [
    {
      label: '총 환자수',
      data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
      borderWidth: 3,
      borderColor: 'black',
      backgroundColor: 'black',
      // tension: 0.4,
    },
    {
      label: '20세 미만',
      data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)], backgroundColor: ['red'],
      borderWidth: 1,
      borderColor: 'red',
      // tension: 0.4,
    },
    {
      label: '20-29세',
      data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)], backgroundColor: ['blue'],
      borderWidth: 1,
      borderColor: 'blue',
      // tension: 0.4,
    },
    {
      label: '30-39세',
      data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
      backgroundColor: ['green'],
      borderWidth: 1,
      borderColor: 'green',
      // tension: 0.4,
    },
    {
      label: '40-49세',
      data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
      backgroundColor: ['purple'],
      borderWidth: 1,
      borderColor: 'purple',
      // tension: 0.4,
    },
    {
      label: '50-59세',
      data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
      backgroundColor: ['orange'],
      borderWidth: 1,
      borderColor: 'orange',
      // tension: 0.4,
    },
    {
      label: '60-69세',
      data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
      backgroundColor: ['brown'],
      borderWidth: 1,
      borderColor: 'brown',
      // tension: 0.4,
    },
    {
      label: '70세 이상',
      data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
      backgroundColor: ['cadetblue'],
      borderWidth: 1,
      borderColor: 'cadetblue',
      // tension: 0.4,
    },
  ]


  var chartArea = document.getElementById('saleChart1').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'line',
    data: {
      labels: ['2017', '2018', '2019', '2020', '2021', '2022'],
      datasets: [
        {
          label: '총 환자수',
          data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)], backgroundColor: ['red'],
          borderWidth: 3,
          borderColor: 'black',
          backgroundColor: 'black',
          // tension: 0.4,
        },
      ]
    },
    options: {
      reponsive: true,
      maintainAspectRatio: false,
      scales: {

        y: {
          grid: {
            display: true,
            color: 'rgba(0, 0, 0, 0.3)',
          },
          beginAtZero: true,
          min: 0,
          max: 16000,
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:1억)' + value;
              } else {
                return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
              }
            },
          },
        },
      },
      plugins: {
        title: {
          display: true,
          text: "충치",
          font: {
            size: 30,
          }
        },
        legend: {
          display: false,
          labels: {
            usePointStyle: true
          },
          onClick: (e, legendItem) => {
            const index = legendItem.datasetIndex;
            const meta = myChart.getDatasetMeta(index);
            meta.hidden = meta.hidden === null ? !myChart.data.datasets[index].hidden : null;
            myChart.update();
          }
        },
      },
    }
  });

  var checkBoxes = document.querySelectorAll('.checkBoxes input')
  // console.log(checkBoxes);

  for (var i = 0; i < checkBoxes.length; i++) {
    checkBoxes[i].onclick = function (event) {
      var result = '';
      if (event.target.checked) {
        result = parseInt(event.target.value);
        console.log(result);
        myChart.data.datasets.push(chartDatasets[result]);
        myChart.update();
      } else {
        result = parseInt(event.target.value);
        for (var j = 0; j < myChart.data.datasets.length; j++) {
          if (myChart.data.datasets[j].label === chartDatasets[result].label) {
            myChart.data.datasets.splice(j, 1);
            break;
          }
        }
        myChart.update();
      }
    }
  }

  diseaseName.onchange = function () {
    var diseaseNames = diseaseName.options[diseaseName.selectedIndex].innerText;
    var title = diseaseNames;
    myChart.options.plugins.title.text = title;

    for (var i = 0; i < myChart.data.datasets.length; i++) {
      var newData = [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000),
      Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)];
      myChart.data.datasets[i].data = newData;
    }
    myChart.update();
  }



}


