window.onload = function () {


  var chartArea = document.getElementById('myChart1').getContext('2d');
  var myChart = new Chart(chartArea, {
    data: {
      labels: ['강동구', '강서구', '강남구', '강북구'],
      datasets: [
        {
          label: '유동 인구',
          data: [10700, 11400, 14000, 9700],
          backgroundColor: ['#40E0D0', '#32CD32', '#FA8072', '#F0E68C'],
          type: 'bar'
        },
        {
          label: '유동 인구 평균',
          data: [11400, 11400, 11400, 11400],
          borderWidth: 1,
          borderColor: 'rgba(16,163,127,1',
          backgroundColor: 'rgba(16,163,127,0.2',
          fill: true,
          type: 'line',
          tension: 0.4,
          pointRadius: 0,
        }
      ]
      
    },
    
    options: {
      reponsive: true,
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 16000,
          // axis: 'y', // y축에 레이블 추가
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:1만) ' + value; // y축 레이블에 표시될 내용 설정
              } else {
                return value;
              }
            },
          },
        },
      },
      plugins: {
        legend: {
          labels: {
            filter: function (legendItem, chartData) {
              return legendItem.text != '유동 인구';
            },
            boxWidth: 20,
            padding: 20,
            boxHeight: 20,
          }
        },
      },
    },
  });

  var chartArea = document.getElementById('myChart2').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'bar',
    data: {
      labels: ['강동구', '강서구', '강남구', '강북구'],
      datasets: [
        {
          label: '치과 개수',
          data: [244, 246, 548, 128],
          backgroundColor: ['#40E0D0', '#32CD32', '#FA8072', '#F0E68C'],
        },
        {
          label: '치과 개수 평균',
          data: [291, 291, 291, 291],
          borderWidth: 1,
          borderColor: 'rgba(16,163,127,1',
          backgroundColor: 'rgba(16,163,127,0.2',
          fill: true,
          type: 'line',
          tension: 0.4,
          pointRadius: 0,
        }
      ]
    },
    options: {
      reponsive: true,
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 800,
          // axis: 'y', // y축에 레이블 추가
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:1개) ' + value; // y축 레이블에 표시될 내용 설정
              } else {
                return value;
              }
            }
          }
        }
      },
      plugins: {
        legend: {
          labels: {
            filter: function (legendItem, chartData) {
              return legendItem.text != '치과 개수';
            },
            boxWidth: 20,
            padding: 20,
            boxHeight: 20,
          }
        },
      },
    },
  });

  var chartArea = document.getElementById('myChart3').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'bar',
    data: {
      labels: ['강동구', '강서구', '강남구', '강북구'],
      datasets: [
        {
          label: '소득 수준',
          data: [6200, 3100, 12000, 3600],
          backgroundColor: ['#40E0D0', '#32CD32', '#FA8072', '#F0E68C'],
        },
        {
          label: '소득 평균',
          data: [8300, 8300, 8300, 8300],
          borderWidth: 1,
          borderColor: 'rgba(16,163,127,1',
          backgroundColor: 'rgba(16,163,127,0.2',
          fill: true,
          type: 'line',
          tension: 0.4,
          pointRadius: 0,
        }
      ]
    },
    options: {
      reponsive: true,
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 16000,
          // axis: 'y', // y축에 레이블 추가
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:1만) ' + value; // y축 레이블에 표시될 내용 설정
              } else {
                return value;
              }
            }
          }
        }
      },
      plugins: {
        legend: {
          labels: {
            filter: function (legendItem, chartData) {
              return legendItem.text != '소득 수준';
            },
            boxWidth: 20,
            padding: 20,
            boxHeight: 20,
          }
        },
      },
    },
  });

  var chartArea = document.getElementById('myChart4').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'bar',
    data: {
      labels: ['강동구', '강서구', '강남구', '강북구'],
      datasets: [
        {
          label: '평당 임대료',
          data: [7, 4.5, 11, 6.5],
          backgroundColor: ['#40E0D0', '#32CD32', '#FA8072', '#F0E68C'],
        },
        {
          label: '평당 임대료 평균',
          data: [6.5, 6.5, 6.5, 6.5],
          borderWidth: 1,
          borderColor: 'rgba(16,163,127,1',
          backgroundColor: 'rgba(16,163,127,0.2',
          fill: true,
          type: 'line',
          tension: 0.4,
          pointRadius: 0,
        }
      ]
    },
    options: {
      reponsive: true,
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 16,
          // axis: 'y', // y축에 레이블 추가
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:1만) ' + value; // y축 레이블에 표시될 내용 설정
              } else {
                return value;
              }
            }
          }
        }
      },
      plugins: {
        legend: {
          labels: {
            filter: function (legendItem, chartData) {
              return legendItem.text != '평당 임대료';
            },
            boxWidth: 20,
            padding: 20,
            boxHeight: 20,
          }
        },
      },
    },
  });

  var posts = [
    { region: "강동구", totalPp: 278800, underFifteen: 21401, twenty: 25114, thirty: 39600, forty: 35829, fifty: 45630, sixty: 47946, seventy: 36584, eighty: 21909, overEighty: 4867 },
    { region: "강서구", totalPp: 543700, underFifteen: 53143, twenty: 45302, thirty: 101756, forty: 87220, fifty: 82477, sixty: 80889, seventy: 58890, eighty: 26996, overEighty: 7027 },
    { region: "강남구", totalPp: 487446, underFifteen: 57127, twenty: 48689, thirty: 70157, forty: 78129, fifty: 91174, sixty: 64478, seventy: 48514, eighty: 23454, overEighty: 5724 },
    { region: "강북구", totalPp: 437762, underFifteen: 50640, twenty: 36998, thirty: 65963, forty: 70989, fifty: 69388, sixty: 68615, seventy: 49471, eighty: 20740, overEighty: 4958 },
  ]

  var tableBody = document.querySelector("#board-table tbody");

  for (var i = 0; i < posts.length; i++) {
    var row = document.createElement("tr");

    var regionCell = document.createElement("th");
    regionCell.textContent = posts[i].region;

    var totalPpCell = document.createElement("td");
    totalPpCell.textContent = posts[i].totalPp;

    var underFifteenCell = document.createElement("td");
    underFifteenCell.textContent = posts[i].underFifteen;

    var twentyCell = document.createElement("td");
    twentyCell.textContent = posts[i].twenty;

    var thirtyCell = document.createElement("td");
    thirtyCell.textContent = posts[i].thirty;

    var fortyCell = document.createElement("td");
    fortyCell.textContent = posts[i].forty;

    var fiftyCell = document.createElement("td");
    fiftyCell.textContent = posts[i].fifty;

    var sixtyCell = document.createElement("td");
    sixtyCell.textContent = posts[i].sixty;

    var seventyCell = document.createElement("td");
    seventyCell.textContent = posts[i].seventy;

    var eightyCell = document.createElement("td");
    eightyCell.textContent = posts[i].eighty;

    var overEightyCell = document.createElement("td");
    overEightyCell.textContent = posts[i].overEighty;

    row.appendChild(regionCell);
    row.appendChild(totalPpCell);
    row.appendChild(underFifteenCell);
    row.appendChild(twentyCell);
    row.appendChild(thirtyCell);
    row.appendChild(fortyCell);
    row.appendChild(fiftyCell);
    row.appendChild(sixtyCell);
    row.appendChild(seventyCell);
    row.appendChild(eightyCell);
    row.appendChild(overEightyCell);

    tableBody.appendChild(row);
  }
}