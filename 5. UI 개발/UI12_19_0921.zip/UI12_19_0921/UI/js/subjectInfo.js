window.onload = function () {
  var code = document.querySelector('#code');
  var codeOption = code.options[code.selectedIndex].innerText;

  
  
  var options = {
    type: 'line',
    data: {
      labels: ['2017년', '2018년', '2019년', '2020년', '2021년', '2022년'],
      datasets: [{
        // label: '인구',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['rgba(255,0,0,0.5)', 'rgba(36, 189, 255, 0.66)'],
        // borderColor: 'none',
        borderWidth: 1
      }]
    },
    options: {
      reponsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 16000,
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:1만)' + value;
              } else {
                return value;
              }
            },
            font: {
              size: 20,
            }
          },
        },
      },
      plugins: {
        title: {
          display: true,
          text: codeOption,
          font: {
            size: 30,
          }
        },
        legend: {
          display: false

        }
      }
    }
  }
  var chartArea = document.getElementById('subjectChart').getContext('2d');
  var myChart = new Chart(chartArea, {
    type: 'line',
    data: {
      labels: ['2017년', '2018년', '2019년', '2020년', '2021년', '2022년'],
      datasets: [{
        // label: '인구',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['rgba(255,0,0,0.5)', 'rgba(36, 189, 255, 0.66)'],
        // borderColor: 'none',
        borderWidth: 1
      }]
    },
    options: {
      reponsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 16000,
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:1만)' + value;
              } else {
                return value;
              }
            },
            font: {
              size: 20,
            }
          },
        },
      },
      plugins: {
        title: {
          display: true,
          text: codeOption,
          font: {
            size: 30,
          }
        },
        legend: {
          display: false

        }
      },
      // responsive: false,
      // scales: {
      //   x:{
      //     ticks:{
      //       font:{
      //         size:30
      //       }
      //     }
      //   },

      // }
    }
  });

  code.onchange = function (myChart) {

    codeOption = code.options[code.selectedIndex].innerText;
    console.log(myChart.options.plugins.title.text);
    // myChart.options.plugins.title.text=codeOption;
    myChart.update();
  }


}
function addData(chart, label, data) {
  chart.data.labels.push(label);
  chart.data.datasets.forEach((dataset) => {
    dataset.data.push(data);
  });
  chart.update();
}
function removeData(chart) {
  chart.data.labels.pop();
  chart.data.datasets.forEach((dataset) => {
    dataset.data.pop();
  });
  chart.update();
}




