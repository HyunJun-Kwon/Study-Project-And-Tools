window.onload = function () {


  var diseaseName = document.querySelector('#diseaseName');
  var diseaseNameOption = diseaseName.options[diseaseName.selectedIndex].innerText;

  var subject = document.querySelector('#subject');
  var subjectOption = subject.options[subject.selectedIndex].innerText;

  var subjectCaption = document.querySelector('#subjectCaption');
  var saleCaption = document.querySelector('#saleCaption');
  subjectCaption.innerText = '*연도별/연령별 ' + diseaseNameOption + ' 환자 수';
  saleCaption.innerText = '*연도별/연령별 ' + diseaseNameOption + ' 매출 수';


  subject.onchange = function () {
    if (subjectOption === '진료 과목') {
      diseaseNameOption.options.length = 0;
      diseaseNameOption.innerText = '상병'
    }
  }
  optionset = [
    {
      reponsive: true,
      maintainAspectRatio: false,
      scales: {

        y: {
          grid: {
            display: true,
            color: 'rgba(0, 0, 0, 0.3)',
          },
          beginAtZero: true,
          min: 0,
          max: 200,
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:만명)' + value;
              } else {
                return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
              }
            },
          },
        },
      },
      plugins: {
        title: {
          display: true,
          text: diseaseNameOption + ' 환자 수 추이',
          font: {
            size: 30,
          }
        },
        legend: {
          display: false,
          labels: {
            usePointStyle: true
          },
          onClick: (e, legendItem) => {
            const index = legendItem.datasetIndex;
            const meta = subjectChart.getDatasetMeta(index);
            meta.hidden = meta.hidden === null ? !subjectChart.data.datasets[index].hidden : null;
            subjectChart.update();
          }
        },
      },
    },
    {
      reponsive: true,
      maintainAspectRatio: false,
      scales: {

        y: {
          grid: {
            display: true,
            color: 'rgba(0, 0, 0, 0.3)',
          },
          beginAtZero: true,
          min: 0,
          max: 16000,
          position: 'top',
          ticks: {
            callback: function (value, index, values) {
              if (index === 0) {
                return '(단위:억원)' + value;
              } else {
                return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
              }
            },
          },
        },
      },
      plugins: {
        title: {
          display: true,
          text: diseaseNameOption + ' 매출 추이',
          font: {
            size: 30,
          }
        },
        legend: {
          display: false,
          labels: {
            usePointStyle: true
          },
          onClick: (e, legendItem) => {
            const index = legendItem.datasetIndex;
            const meta = saleChart.getDatasetMeta(index);
            meta.hidden = meta.hidden === null ? !saleChart.data.datasets[index].hidden : null;
            saleChartChart.update();
          }
        },
      },
    }
  ]


  var data = {
    patientCount: {
      ['K05']: [[150, 157, 160, 154, 170, 180], [10, 12, 14, 16, 18, 19], [20, 25, 24, 26, 28, 21], [30, 35, 37, 34, 31, 39], [41, 40, 48, 42, 46, 43], [55, 57, 51, 59, 53, 56], [67, 61, 64, 69, 62, 65], [71, 76, 73, 79, 72, 75]],
      ['K02']: [[158, 151, 140, 164, 180, 110], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)]],
      ['K04']: [[150, 157, 160, 154, 170, 180], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)]],
      ['K07']: [[158, 151, 140, 164, 180, 110], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)]],
      ['K08']: [[150, 157, 160, 154, 170, 180], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)], [Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100), Math.round(Math.random() * 100)]]
    },
    saleCount: {
      K05: [],
      K02: [],
      K04: [],
      K07: [],
      K08: []
    }
  }
  console.log(Object.keys(data.patientCount)[1])





  var chartData = [
    [
      {
        label: '총 환자수',
        data: [150, 157, 160, 154, 170, 180],
        borderWidth: 3,
        borderColor: 'black',
        backgroundColor: 'black',
        // tension: 0.4,
      },
      {
        label: '20세 미만',
        data: [10, 12, 14, 16, 18, 19],
        backgroundColor: ['red'],
        borderWidth: 1,
        borderColor: 'red',
        // tension: 0.4,
      },
      {
        label: '20-29세',
        data: [20, 25, 24, 26, 28, 21],
        backgroundColor: ['blue'],
        borderWidth: 1,
        borderColor: 'blue',
        // tension: 0.4,
      },
      {
        label: '30-39세',
        data: [30, 35, 37, 34, 31, 39],
        backgroundColor: ['green'],
        borderWidth: 1,
        borderColor: 'green',
        // tension: 0.4,
      },
      {
        label: '40-49세',
        data: [41, 40, 48, 42, 46, 43],
        backgroundColor: ['purple'],
        borderWidth: 1,
        borderColor: 'purple',
        // tension: 0.4,
      },
      {
        label: '50-59세',
        data: [55, 57, 51, 59, 53, 56],
        backgroundColor: ['orange'],
        borderWidth: 1,
        borderColor: 'orange',
        // tension: 0.4,
      },
      {
        label: '60-69세',
        data: [67, 61, 64, 69, 62, 65],
        backgroundColor: ['brown'],
        borderWidth: 1,
        borderColor: 'brown',
        // tension: 0.4,
      },
      {
        label: '70세 이상',
        data: [71, 76, 73, 79, 72, 75],
        backgroundColor: ['cadetblue'],
        borderWidth: 1,
        borderColor: 'cadetblue',
        // tension: 0.4,
      }
    ],
    [
      {
        label: '총 환자수',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        borderWidth: 3,
        borderColor: 'black',
        backgroundColor: 'black',
        // tension: 0.4,
      },
      {
        label: '20세 미만',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)], backgroundColor: ['red'],
        borderWidth: 1,
        borderColor: 'red',
        // tension: 0.4,
      },
      {
        label: '20-29세',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)], backgroundColor: ['blue'],
        borderWidth: 1,
        borderColor: 'blue',
        // tension: 0.4,
      },
      {
        label: '30-39세',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['green'],
        borderWidth: 1,
        borderColor: 'green',
        // tension: 0.4,
      },
      {
        label: '40-49세',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['purple'],
        borderWidth: 1,
        borderColor: 'purple',
        // tension: 0.4,
      },
      {
        label: '50-59세',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['orange'],
        borderWidth: 1,
        borderColor: 'orange',
        // tension: 0.4,
      },
      {
        label: '60-69세',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['brown'],
        borderWidth: 1,
        borderColor: 'brown',
        // tension: 0.4,
      },
      {
        label: '70세 이상',
        data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)],
        backgroundColor: ['cadetblue'],
        borderWidth: 1,
        borderColor: 'cadetblue',
        // tension: 0.4,
      }
    ]
  ]
  var subjectArea = document.getElementById('patientChart').getContext('2d');
  var subjectChart = new Chart(subjectArea, {
    type: 'line',
    data: {
      labels: ['2017', '2018', '2019', '2020', '2021', '2022'],
      datasets: [
        {
          label: '총 환자수',
          data: [150, 157, 160, 154, 170, 180],
          borderWidth: 3,
          borderColor: 'black',
          backgroundColor: 'black',
          // tension: 0.4,
        },
      ]
    },
    options: optionset[0]
  });

  var saleArea = document.getElementById('saleChart').getContext('2d');
  var saleChart = new Chart(saleArea, {
    type: 'line',
    data: {
      labels: ['2017', '2018', '2019', '2020', '2021', '2022'],
      datasets: [
        {
          label: '총 환자수',
          data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)], backgroundColor: ['red'],
          borderWidth: 3,
          borderColor: 'black',
          backgroundColor: 'black',
          // tension: 0.4,
        },
      ]
    },
    options: optionset[1]
  });

  var checkBoxes = document.querySelectorAll('.checkBoxes input')
  // console.log(checkBoxes);

  for (var i = 0; i < checkBoxes.length; i++) {
    checkBoxes[i].onclick = function (event) {
      var result = '';
      if (event.target.checked) {
        result = parseInt(event.target.value);
        console.log(result);
        subjectChart.data.datasets.push(chartData[0][result]);
        saleChart.data.datasets.push(chartData[1][result]);
        subjectChart.update();
        saleChart.update();
      } else {
        result = parseInt(event.target.value);
        for (var j = 0; j < saleChart.data.datasets.length; j++) {
          if (saleChart.data.datasets[j].label === chartData[0][result].label) {
            saleChart.data.datasets.splice(j, 1);
            subjectChart.data.datasets.splice(j, 1)
            break;
          }
        }
        subjectChart.update();
        saleChart.update();
      }
    }
  }

  diseaseName.onchange = function () {
    var diseaseNames = diseaseName.options[diseaseName.selectedIndex].innerText;
    var diseaseOption = diseaseName.options[diseaseName.selectedIndex].value;
    var title = diseaseNames;
    saleChart.options.plugins.title.text = title;
    subjectChart.options.plugins.title.text = title;

    var subjectCaption = document.querySelector('#subjectCaption');
    var saleCaption = document.querySelector('#saleCaption');
    subjectCaption.innerText = '*연도별/연령별 ' + title + ' 환자 수';
    saleCaption.innerText = '*연도별/연령별 ' + title + ' 매출 수';

    console.log(diseaseOption)

    for (var i = 0; i < Object.keys(data.patientCount).length; i++) {
      if (diseaseOption === Object.keys(data.patientCount)[i]) {
        for (var j = 0; j < data.patientCount[diseaseOption].length; j++) {
          var newData = data.patientCount[diseaseOption][j]
          console.log(newData)    
          subjectChart.data.datasets.push({
            label: '총 환자수',
            data: [Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000), Math.floor(Math.random() * 10000)], backgroundColor: ['red'],
            borderWidth: 3,
            borderColor: 'black',
            backgroundColor: 'black',
            // tension: 0.4,
          });
            subjectChart.data.datasets[j].data = newData;
          
        }
        break;
      }
    }
    // for(var i=0 ; Object.keys(data.patientCount).length;i++){
    //   var newData = data.patientCount[diseaseOption][i];
    //   // console.log(data.patientCount[diseaseOption][])
    //   // saleChart.data.datasets[i].data = newData;
    //   subjectChart.data.datasets[0].data= newData;
    //   subjectChart.update();
    // }

    // var tableData = document.querySelectorAll('#tbody tr td');
    // var k = 0;
    //  for( var i= 0 ; i< chartData[0][0].data.length; i++){
    //   for(var j=0; j<chartData[0].length; j++){
    //     tableData[k].innerText=chartData[0][j].data[i];
    //     k++;
    //   }
    //  } 


    saleChart.update();
    subjectChart.update();
  }

  var showSubjectBtn = document.querySelector('#showSubjectTable');
  var subjectTable = document.querySelector('#subjectTable');
  showSubjectBtn.onclick = function () {

    if (subjectTable.style.display === 'none') {
      subjectTable.style.display = 'block';
    } else {
      subjectTable.style.display = 'none'
    }
  }
  var showSaleBtn = document.querySelector('#showSaleTable');
  var saleTable = document.querySelector('#saleTable');
  showSaleBtn.onclick = function () {

    if (saleTable.style.display === 'none') {

      saleTable.style.display = 'block';
    } else {
      saleTable.style.display = 'none'
    }
  }

}

